
const tbcontent = document.querySelectorAll('.tabcontent')
const tbItem = document.querySelectorAll('.tabheader__item')
const tbItems = document.querySelector('.tabheader__items')



function hidContent (){
    tbcontent.forEach(item =>{
        item.style.display = 'none'
    })
   tbItem.forEach(item =>{
       item.classList.remove('active')
   })

}
hidContent()

function showContent(g=2) {
    tbcontent[g].style.display = 'block' , '.fade'
    tbItem[g].classList.add('active')
}
hidContent()
showContent()

tbItems.addEventListener('click' ,(event)=> {
    const target = event.target

    if (target.classList.contains('tabheader__item')){
        tbItem.forEach((item,i) =>{
            if (target === item) {
                hidContent()
                showContent(i)
            }
        })
    }
})



///modal

const modal = document.querySelector('.modal')
const modalButton = document.querySelector('[data-modal]')
const closeModalButton = document.querySelector('.modal__close')



modalButton.addEventListener('click' , ()=>{
    modal.classList.add('show_files' , '.tr')
    modal.classList.remove('.close_files')
    document.body.style.overflow = 'hidden'
})


closeModalButton.addEventListener('click' , () => {
    modal.classList.add('close_files' , '.tr')
    modal.classList.remove('show_files')
    document.style.overflow = ''
})


modal.addEventListener('mousemove' ,()=>{
    modal.classList.add('active')
} )