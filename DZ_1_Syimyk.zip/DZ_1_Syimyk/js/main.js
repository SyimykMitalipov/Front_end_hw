


// const myStr = prompt('Enter your name')
//
// const myExp = /\w/ig
//
// console.log(myStr.replace(myExp , '*'
const phoneInput =  document.querySelector('#phoneInput') ,
    myBtn = document.querySelector('#phoneSumbit') ,
    resultMynumber = document.querySelector('#resultOfnumber')



const myExp = /^\+996|0 \d{3}-\d{3}-\d{3}$/ //// Использовал | "ИЛИ"
 
myBtn.addEventListener('click' ,() => {
    if (myExp.test(phoneInput.value)) {
       resultMynumber.innerText = 'SEND';
       resultMynumber.style.color = 'green'
    }else {
    resultMynumber.innerText = 'ERROR!';
    resultMynumber.style.color = 'red'
    }
} )